#!/usr/bin/env bash
set -euo pipefail

PYTHON_BIN="${PYTHON_BIN:-python3.13}"

echo "Using Python: ${PYTHON_BIN}"
"${PYTHON_BIN}" -m pip install --no-index --find-links ./wheelhouse -r requirements_no_langchain.txt

echo "Install finished."
