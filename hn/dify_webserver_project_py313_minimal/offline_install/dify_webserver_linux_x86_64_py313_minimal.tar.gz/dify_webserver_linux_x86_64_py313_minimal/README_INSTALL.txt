离线安装包：dify_webserver Linux x86_64 Python 3.13 minimal

这个包只安装网页服务运行需要的基础依赖：
Flask、Flask-Cors、Flask-Login、requests、urllib3、Werkzeug、psutil 及其依赖。

不包含本地知识检索相关依赖；知识库检索请在 Dify 中维护。

安装方法：
1. 把项目代码和本安装包复制到目标离线机器。
2. 解压安装包：
   tar -xzf dify_webserver_linux_x86_64_py313_minimal.tar.gz
3. 进入安装包目录：
   cd dify_webserver_linux_x86_64_py313_minimal
4. 执行安装：
   chmod +x install.sh
   ./install.sh

如果目标机器 Python 命令不是 python3.13：
   PYTHON_BIN=/实际路径/python3.13 ./install.sh

回到项目目录启动：
   python3.13 dify_web_server_.py

访问地址：
   http://服务器IP:5001
